WHATNOT PURCHASE FINDER v9 — GITHUB PAGES UPDATE

Upload/replacement in https://github.com/cmak4563/Whatnot-Purchase-Tracker (main branch, repository root):
  index.html
  service-worker.js
  version.json (NEW)

The icon files and manifest.webmanifest are included for completeness but do not need replacing if already present.

On Android: first back up edits in the existing app, then upload the three files above via GitHub. The installed app icon stays the same. After GitHub Pages finishes publishing, close/reopen the app while online; v9 will load. Later, use Check for Updates.

For EVERY later release, update ALL THREE: index.html (visible version and CURRENT JavaScript constant), version.json (version), and service-worker.js (CACHE constant). Keep the same site URL and annotation localStorage key. The button checks version.json live and reloads when newer. If a future release isn't uploaded completely, a version check may detect the release before all files deploy; GitHub Pages publishes commits atomically when files are committed together.

No user CSV or backup files belong on GitHub. Data remains in the browser storage on that device; back it up before updates. Outside services (TCGdex, TCGplayer and exchange rates) still require internet.

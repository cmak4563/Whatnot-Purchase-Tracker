WHATNOT FINDER - INSTALLABLE ANDROID HOME-SCREEN APP

This is the original v8 Purchase Finder, packaged as an installable Progressive Web App (PWA), with a custom icon.

SETUP (requires HTTPS hosting; opening index.html from Downloads will NOT install it):
1. Back up edits from your existing v8 app (Back up edits).
2. On GitHub create a new PUBLIC repository, for example whatnot-finder.
3. Upload the five app files (index.html, manifest.webmanifest, service-worker.js, icon-192.png, icon-512.png) to the root of the repository. DO NOT upload your CSV or annotation backup.
4. Repository Settings -> Pages -> Deploy from a branch -> main / (root) -> Save.
5. After Pages publishes, open https://YOURNAME.github.io/whatnot-finder/ in Chrome on your Android phone.
6. Chrome menu (three dots) -> Add to Home screen -> Install. It will open as a standalone application with its own icon.
7. Import the CSV and restore your edits backup IN THE INSTALLED APP. Web-origin storage differs from local HTML storage.

PRIVACY: Do not put purchases CSV, personal annotations, or other private information into a public GitHub repository. The app code only is published. Purchases are read locally in your browser. Card imagery and historical currency rates use external online APIs when requested.

OFFLINE: the app shell will open offline after initial load, but TCGdex image search, remote card images, and Frankfurter conversion lookup need internet.

To create an actual APK file instead, an Android SDK compilation environment is required; this ZIP is a PWA, NOT an APK.
